data = LOAD 'gs://my-hive-warehouse-1/data/Clothing_Shoes_and_Jewelry.json' USING JsonLoader('id:(oid:chararray), reviewerID:chararray, asin:chararray, reviewerName:chararray, helpful:{(h0:int, h1:int)}, reviewText:chararray, overall:int, summary:chararray, unixReviewTime:int, reviewTime:chararray, category:chararray, class:int');
A = FILTER data BY reviewerName is not null;
B = FILTER A BY reviewText is not null;
C = FILTER B BY summary is not null;
D = FILTER C BY reviewerName != 'Amazon Customer';
E = FOREACH D GENERATE reviewerID, asin, LOWER(reviewerName) as reviewerName, LOWER(reviewText) as reviewText, overall, LOWER(summary) as summary, reviewTime, SIZE(reviewText) as length;
SPAM = FILTER E BY length > 200;
F = GROUP SPAM BY reviewerName;
G = FOREACH F GENERATE FLATTEN(group) as reviewerName, COUNT($1) as count;
H = ORDER G BY count DESC;
I = LIMIT H 10;
STORE I INTO 'gs://my-hive-warehouse-1/data/users_spam.json' USING JsonStorage();

NO_SPAM = FILTER E BY length <= 200;
J = GROUP NO_SPAM BY reviewerName;
K = FOREACH J GENERATE FLATTEN(group) as reviewerName, COUNT($1) as count;
L = ORDER K BY count DESC;
M = LIMIT L 10;
STORE M INTO 'gs://my-hive-warehouse-1/data/users_no_spam.json' USING JsonStorage();

TEXT_SPAM = JOIN E BY reviewerName, I BY reviewerName;
TEXT_NO_SPAM = JOIN E BY reviewerName, M by reviewerName;
RES_SPAM = FOREACH TEXT_SPAM GENERATE E::reviewerID as reviewerID, E::asin as asin, E::reviewerName as reviewerName, E::reviewText as reviewText, E::overall as overall, E::summary as summary, E::reviewTime as reviewTime, E::length as length, I::count as count;
RES_NO_SPAM = FOREACH TEXT_NO_SPAM GENERATE E::reviewerID as reviewerID, E::asin as asin, E::reviewerName as reviewerName, E::reviewText as reviewText, E::overall as overall, E::summary as summary, E::reviewTime as reviewTime, E::length as length, M::count as count;

STORE RES_SPAM INTO 'gs://my-hive-warehouse-1/data/spam.json' USING JsonStorage();
STORE RES_NO_SPAM INTO 'gs://my-hive-warehouse-1/data/no_spam.json' USING JsonStorage();
