#!/usr/bin/python

import sys
import os

#input: ((word, doc_id), (wordcount, total_count))
#output: (word, (word, doc_id), (wordcount, total_count))
for line in sys.stdin:
	line = line.strip()
	key, value = line.split('\t', 1)
	word, doc = key.split(' ', 1)
	count, total = value.split(' ', 1)
	word_doc = str(word) + ' ' + str(doc)
	counts = str(count) + ' ' + str(total)
	print('%s\t%s\t%s' % (str(word), word_doc, counts))