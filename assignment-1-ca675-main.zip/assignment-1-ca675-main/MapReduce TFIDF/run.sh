hadoop jar /usr/lib/hadoop/hadoop-streaming.jar \
-file /home/nuria_canteromontana2/wordcount_mapper.py \
-mapper  'python3 wordcount_mapper.py' \
-file /home/nuria_canteromontana2/wordcount_reducer.py \
-reducer 'python3 wordcount_reducer.py' \
-input gs://my-hive-warehouse-1/data/NO_SPAM/amanda.txt \
-output gs://my-hive-warehouse-1/data/NO_SPAM/amanda/out1

hadoop jar /usr/lib/hadoop/hadoop-streaming.jar \
-file /home/nuria_canteromontana2/wordperdoc_mapper.py \
-mapper  'python3 wordperdoc_mapper.py' \
-file /home/nuria_canteromontana2/wordperdoc_reducer.py \
-reducer 'python3 wordperdoc_reducer.py' \
-input gs://my-hive-warehouse-1/data/NO_SPAM/amanda/out1/ \
-output gs://my-hive-warehouse-1/data/NO_SPAM/amanda/out2

hadoop jar /usr/lib/hadoop/hadoop-streaming.jar \
-file /home/nuria_canteromontana2/tfidf_mapper.py \
-mapper  'python3 tfidf_mapper.py' \
-file /home/nuria_canteromontana2/tfidf_reducer.py \
-reducer 'python3 tfidf_reducer.py' \
-input gs://my-hive-warehouse-1/data/NO_SPAM/amanda/out2/ \
-output gs://my-hive-warehouse-1/data/NO_SPAM/amanda/out3

hadoop jar /usr/lib/hadoop/hadoop-streaming.jar \
-file /home/nuria_canteromontana2/final_mapper.py \
-mapper  'python3 final_mapper.py' \
-input gs://my-hive-warehouse-1/data/NO_SPAM/amanda/out3/ \
-output gs://my-hive-warehouse-1/data/NO_SPAM/amanda/final