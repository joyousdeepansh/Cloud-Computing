#!/usr/bin/python

import sys

#input: ((word, doc_id), 1)
#output: (doc_id, (word, 1))
for line in sys.stdin:
	line = line.strip()
	key, count = line.split('\t', 1)
	word, doc = key.split(' ', 1)
	value = str(word) + ' ' + str(count)
	print('%s\t%s' % (str(doc), value))
