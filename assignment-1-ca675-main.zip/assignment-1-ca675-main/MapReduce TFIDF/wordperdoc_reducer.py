#!/usr/bin/python

import sys
import os

#input: (doc_id, (word, 1))
#output: ((word, doc_id), (wordcount, total_count))
word_doc = {}
lines = []

for line in sys.stdin:
	line = line.strip()
	lines.append(line)
	doc, value = line.split('\t', 1)
	word, count = value.split(' ', 1)
	count = int(count)
	# add to dictionary
	if doc not in word_doc:
		word_doc[doc] = count
	else: #add to total wordcount for each doc
		word_doc[doc] += count

for line in lines:
	doc, value = line.split('\t', 1)
	word, count = value.split(' ', 1)
	for d in word_doc:
		if doc == d:
			key = str(word) + ' ' + str(doc)
			value = str(count) + ' ' + str(word_doc[d])
			print('%s\t%s' % (key, value))