#!/usr/bin/python

import sys
import os


#input: (word, 1)
#output: ((word, doc_id), wordcount)
previous = None
total_count = 0
key = None

for line in sys.stdin:
    line = line.strip()
    key, count = line.split('\t', 1)
    count = int(count)
    # mapper sorts words alphabetically
    if previous == key:
        total_count = total_count + count
    else:
        if previous:
            print("%s\t%s" % (previous, total_count))
        total_count = count
        previous = key
if previous == key and previous is not None:
    print('%s\t%s' % (previous, total_count))
