#!/usr/bin/python

import sys
import os

#input: ((word, doc_id), tfidf)
#output: (tfidf, word)
# mapper used to sort by tfidf and find the highest 10
for line in sys.stdin:
	line = line.strip()
	key, tfidf = line.split('\t', 1)
	word, doc = key.split(' ', 1)
	tfidf = float(tfidf)
	print('%10.10f\t%s' % (tfidf, word))
