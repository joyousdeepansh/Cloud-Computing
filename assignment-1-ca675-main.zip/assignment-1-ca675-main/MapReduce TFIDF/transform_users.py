import pandas as pd

df = pd.read_json('data-merged_no_spam.json', lines = True)
df = df[['reviewText', 'reviewerName']]
for i in pd.unique(df['reviewerName']):
      tmp = df[df['reviewerName']==i]
      tmp = tmp['reviewText']
      tmp.to_csv('%s.txt'%i, index = False)