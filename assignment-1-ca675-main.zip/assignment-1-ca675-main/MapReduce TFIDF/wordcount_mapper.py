#!/usr/bin/python

import os
import sys
import re

#input: text
#output: (word, 1)
# used to remove all the stopwords
stopwords= ['a','able','about','across','after','all','almost','also','am','among','an','and','any','are','as','at','be','because','been','but','by',
            'can','cannot','could','dear','did','do','does','either','else','ever','every','for','from','get','got','had','has','have','he','her','hers',
            'him','his','how','however','i','if','in','into','is','it','its','just','least','let','like','likely','may','me','might','most','must','my',
            'neither','no','nor','not','of','off','often','on','only','or','other','our','own','rather','said','say','says','she','should','since','so',
            'some','than','that','the','their','them','then','there','these','they','this','tis','to','too','twas','us','wants','was','we','were','what',
            'when','where','which','while','who','whom','why','will','with','would','yet','you','your', 'reviewtext']
# used to remove unwanted characters
unwanted = '!@#$;:?*%)(&^~-_€/..,-"""'''
doc_id = 0
#wordcount mapper
for line in sys.stdin:
	filename = os.environ["map_input_file"]
	doc_id = doc_id + 1
	# delete whitespace at beginning and end
	line = line.strip()
	for char in unwanted:
		line = line.replace(char, "")
	# create array for each word
	words = line.split()
	for word in words:
		word = word.lower()
		if word not in stopwords:
			z=word+' '+str(doc_id);
			print('%s\t%s' % (z, 1))

