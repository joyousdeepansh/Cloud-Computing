#!/usr/bin/python

import sys
import os
import math

#input: (word, (word, doc_id), (count, total_count))
#output: ((word, doc_id), tfidf)
lines = []
df_t = {}
docs = []

# df_t = number of times a word appears in the docs
for line in sys.stdin:
	line = line.strip()
	lines.append(line)
	word, values = line.split('\t', 1)
	key, value = values.split('\t', 1)
	word, doc = key.split(' ', 1)
	count, total = value.split(' ', 1)
	if word not in df_t:
		df_t[word] = 1
	else:
		df_t[word] += 1
	if doc not in docs:
		docs.append(doc)
# n_docs = total number of documents
n_docs = len(docs)
for line in lines:
	word, values = line.split('\t', 1)
	key, value = values.split('\t', 1)
	word, doc = key.split(' ', 1)
	count, total = value.split(' ', 1)
	# tf_t_d = number of times a word appears in a doc
	tf_t_d = float(count)
	# n_d = number of words in a doc
	n_d = float(total)
	tf = tf_t_d/n_d
	idf = math.log10(n_docs/df_t[word])
	tfidf = tf*idf
	key = str(word) + ' ' + str(doc)
	print('%10.10f\t%s' % (key, tfidf))
