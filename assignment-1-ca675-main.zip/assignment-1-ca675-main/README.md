# Assignment 1 CA675

The [dataset](https://www.kaggle.com/datasets/naveedhn/amazon-product-review-spam-and-non-spam) can be found here.

The PIG queries folder contains the file used to clean the dataset and obtain the top 10 user for ham and spam.<br>
The MapReduce TFIDF folder contains all the necessary code to compute the TFIDF for each word in each comment of the top 10 ham and spam accounts.<br>
The Results folder contains the list of the top 10 users as well as the top 10 words for each top 10 account computed using TFIDF.<br>
